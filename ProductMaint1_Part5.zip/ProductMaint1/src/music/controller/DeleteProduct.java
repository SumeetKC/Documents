package music.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import music.business.Product;
import music.data.ProductDB;

/**
 * Servlet implementation class DeleteProduct
 */
@WebServlet("/deleteProduct")
public class DeleteProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String code = (String) request.getParameter("code");
		String description = (String) request.getParameter("description");
		String price = (String) request.getParameter("price");
		
		Product p = new Product();
		p.setCode(code);
		p.setDescription(description);
		p.setPrice(Double.valueOf(price));
		
		if(ProductDB.exists(code))
			ProductDB.deleteProduct(p);
		
		
		
		//Displaying products
				List<Product> productList = ProductDB.selectProducts();
				request.setAttribute("productList", productList);
				RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/jsp/displayProducts.jsp");
				rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
