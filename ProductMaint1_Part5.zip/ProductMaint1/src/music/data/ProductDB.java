package music.data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import music.business.Product;

public class ProductDB {

	private static List<Product> products = null;
	private static final String classNAME = "product";
	private static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(classNAME);

	private ProductDB() {
	}

	@SuppressWarnings("unchecked")
	public static List<Product> selectProducts() {
		products = new ArrayList<Product>();
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {

			Query query = entityManager.createQuery("select p from Product p");
			products = query.getResultList();
			entityManager.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return products;

	}

	public static Product selectProduct(String productCode) {
		products = selectProducts();
		for (Product p : products) {
			if (productCode != null && productCode.equalsIgnoreCase(p.getCode())) {
				return p;
			}
		}
		return null;
	}

	public static boolean exists(String productCode) {
		if (productCode != null) {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			Product p = entityManager.find(Product.class, productCode);
			entityManager.getTransaction().commit();
			if (p != null && productCode.equalsIgnoreCase(p.getCode())) {
				return true;
			} else
				return false;
		}

		return false;

	}

	public static void insertProduct(Product product) {

		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(product);
			entityManager.getTransaction().commit();
			entityManager.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void updateProduct(Product product) {
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			Product p = entityManager.find(Product.class, product.getCode());
			p.setDescription(product.getDescription());
			p.setPrice(product.getPrice());
			entityManager.getTransaction().commit();
			entityManager.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void deleteProduct(Product product) {
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			Product p = entityManager.find(Product.class, product.getCode());
			entityManager.remove(p);
			entityManager.getTransaction().commit();
			entityManager.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
