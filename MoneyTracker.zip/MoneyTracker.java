import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MoneyTracker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please Enter Student ID");
			String id = reader.readLine();
			System.out.println("Please Enter Student Name");
			String name = reader.readLine();
			System.out.println("To Start Press 1");
			System.out.println("To Exit Press 2");
			
			int choice = Integer.parseInt(reader.readLine());
			if(choice ==1)
			{
				System.out.println("#############################################");
				System.out.println("\tWelcome to my system");
				System.out.println("\tStudent ID - "+id);
				System.out.println("\tStudent Name - "+name);
				System.out.println("\t"+new SimpleDateFormat("dd/mm/yyyy").format(new Date()));
				System.out.println("#############################################");
			}
			else if(choice == 2)
			{
				System.out.println("#############################################");
				System.out.println("\tThanks for using this system\n\tGood Bye");
				System.out.println("\tStudent ID - "+id);
				System.out.println("\tStudent Name - "+name);
				System.out.println("#############################################");
			}
			else
			{
				throw new Exception("Invalid Option");
			}
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
