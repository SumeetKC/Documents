public class Tax {

	double calculatedTax = 0;
	int highTaxGroup = 0;

	public Tax() {

	}

	public double calculateTax(double taxableIncome) {

		if (taxableIncome >= 0 && taxableIncome <= 18200) {
			
			calculatedTax = 0;

		} else if (taxableIncome >= 18201 && taxableIncome <= 37000) {
			
			calculatedTax = ((taxableIncome - 18200) * 0.19);

		} else if (taxableIncome >= 37001 && taxableIncome <= 87000) {
			
			calculatedTax = ((taxableIncome - 37000) * 0.325) + 3572;

		} else if (taxableIncome >= 87001 && taxableIncome <= 180000) {
			
			calculatedTax = ((taxableIncome - 87000) * 0.37) + 19822;

		}else if(taxableIncome >= 180001)
		{
			calculatedTax = ((taxableIncome - 180000) * 0.45) + 54097;
		}

		return calculatedTax;
	}

	public int highestTaxGroup(int group1, int group2, int group3, int group4,
			int group5) {
		
		highTaxGroup = Math.max(Math.max(Math.max(group1, group2), Math.max(group3, group4)), group5);

		return highTaxGroup;

	}
}
