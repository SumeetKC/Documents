import java.util.Scanner;

public class TaxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int n = 6;
		double taxableIncome = 0;
		double calculatedTax = 0;
		double highestTax = 0;
		double lowestTax = 0;
		int highTaxGroup = 0;
		int group1 = 0;
		int group2 = 0;
		int group3 = 0;
		int group4 = 0;
		int group5 = 0;
		Tax tax = new Tax();
		try {

			Scanner scanner = new Scanner(System.in);
			System.out.println("Welcome to the Tax Calculation System");
			System.out.println("Please enter taxable income for " + n
					+ " employees");

			for (int i = 1; i <= n; i++) {
				
				System.out.println("Enter the taxable income for employee " + i	+ ": ");
				taxableIncome = scanner.nextDouble();
				//Tax Calculation
				calculatedTax = tax.calculateTax(taxableIncome);
				System.out.println("The income tax for employee " + i + " is $"	+ calculatedTax);
				
				//Highest Tax and Lowest Tax Calculation
				if (calculatedTax > highestTax) {
					highestTax = calculatedTax;
				} else {
					lowestTax = calculatedTax;
				}

				// Logic for grouping
				if (taxableIncome >= 0 && taxableIncome <= 18200) {

					group1++;

				} else if (taxableIncome >= 18201 && taxableIncome <= 37000) {

					group2++;

				} else if (taxableIncome >= 37001 && taxableIncome <= 87000) {

					group3++;

				} else if (taxableIncome >= 87001 && taxableIncome <= 180000) {

					group4++;

				} else if (taxableIncome >= 180001) {
					group5++;
				}

			}

			highTaxGroup = tax.highestTaxGroup(group1, group2, group3, group4,
					group5);

			scanner.close();
			System.out.println("\n");
			System.out.println("***********************************Report*******************************");
			System.out.println("Highest Tax: $" + highestTax);
			System.out.println("Lowest Tax: $" + lowestTax);
			System.out.println("Number of employees in Group 1: " + group1);
			System.out.println("Number of employees in Group 5: " + group5);
			System.out.println("Tax group number with highest number of employees: " + highTaxGroup);
			System.out.println("************************************************************************\n");
			System.out.println("Thanks for using the system");

		} catch (Exception ex) {
			System.out.println("Error Occurred due to below");
			ex.printStackTrace();
		}

	}
}
