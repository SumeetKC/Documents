package music.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import music.business.Product;

public class ProductDB {
	//private static BasicDataSource dataSource = new BasicDataSource();
	private static List<Product> products = null;

	/*
	 * static { dataSource.setUrl("jdbc:mysql://localhost:3306/mydb");
	 * dataSource.setUsername("root"); dataSource.setPassword("root");
	 * dataSource.setMinIdle(5); dataSource.setMaxIdle(10);
	 * dataSource.setMaxOpenPreparedStatements(100); }
	 */

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
	}

	private ProductDB() {
	}
	
	public static List<Product> selectProducts() {
		products = new ArrayList<Product>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = getConnection();
			PreparedStatement smt = connection.prepareStatement("select * from product");
			ResultSet rs = smt.executeQuery();
			while(rs.next())
			{
				Product p = new Product();
				p.setId(rs.getLong(1));
				p.setCode(rs.getString(2));
				p.setDescription(rs.getString(3));
				p.setPrice(rs.getDouble(4));
				
				products.add(p);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return products;
		
	}
	
	
	public static Product selectProduct(String productCode) {
		products = selectProducts();
		for (Product p : products) {
			if (productCode != null && productCode.equalsIgnoreCase(p.getCode())) {
				return p;
			}
		}
		return null;
	}
	
	public static boolean exists(String productCode) {
		Product p = selectProduct(productCode);
		if (p != null)
			return true;
		else
			return false;
	}
	
	public static void insertProduct(Product product) {
		
		try {
			Connection connection = getConnection();
			PreparedStatement smt = connection.prepareStatement("insert into product (code,description,price) values (?,?,?);");
			smt.setString(1, product.getCode());
			smt.setString(2, product.getDescription());
			smt.setString(3, String.valueOf(product.getPrice()));
			
			smt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void updateProduct(Product product) {
		products = selectProducts();
		for (int i = 0; i < products.size(); i++) {
			Product p = products.get(i);
			if (product.getCode() != null && product.getCode().equalsIgnoreCase(p.getCode())) {
				try {
					Connection connection = getConnection();
					PreparedStatement smt = connection.prepareStatement("update product set description=?, price=? where code=?");
					smt.setString(1, product.getDescription());
					smt.setDouble(2, product.getPrice());
					smt.setString(3, product.getCode());
					
					smt.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static void deleteProduct(Product product) {
		products = selectProducts();
		for (int i = 0; i < products.size(); i++) {
			Product p = products.get(i);
			if (product != null && product.getCode().equalsIgnoreCase(p.getCode())) {
				try {
					Connection connection = getConnection();
					PreparedStatement smt = connection.prepareStatement("delete from product where code=?");
					smt.setString(1, product.getCode());
					
					smt.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
}